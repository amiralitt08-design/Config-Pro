<?php
/**
 * WooCommerce wrapper: shop, product, cart, checkout and account pages.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>
<main id="content" class="container wc-wrap">
	<?php woocommerce_content(); ?>
</main>
<?php
get_footer();
