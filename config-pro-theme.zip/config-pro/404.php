<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>
<main id="content" class="container">
	<div class="prose" style="text-align:center;padding:80px 0">
		<h1 class="grad" style="font-size:64px">۴۰۴</h1>
		<p><?php esc_html_e( 'صفحه‌ای که دنبالش بودید پیدا نشد.', 'config-pro' ); ?></p>
		<a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'بازگشت به خانه', 'config-pro' ); ?></a>
	</div>
</main>
<?php
get_footer();
