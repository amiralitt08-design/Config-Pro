(function () {
  var t = document.querySelector('.menu-toggle'), n = document.querySelector('.nav');
  if (!t || !n) return;
  t.addEventListener('click', function () {
    var open = n.classList.toggle('open');
    t.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
})();
