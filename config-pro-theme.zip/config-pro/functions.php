<?php
/**
 * Config Pro - functions
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CPRO_VER', '1.0.0' );

require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/setup-wizard.php';

/* ---------- Theme setup ---------- */
add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'config-pro', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 60, 'width' => 200, 'flex-width' => true, 'flex-height' => true ) );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/editor.css' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	register_nav_menus( array(
		'primary' => 'منوی اصلی',
		'footer'  => 'منوی فوتر',
	) );
} );

add_action( 'widgets_init', function () {
	register_sidebar( array(
		'name'          => 'سایدبار وبلاگ',
		'id'            => 'sidebar-1',
		'before_widget' => '<div class="card widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
} );

/* ---------- Assets (no external fonts or CDNs, works without VPN) ---------- */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'config-pro', get_stylesheet_uri(), array(), CPRO_VER );
	$a1 = sanitize_hex_color( cpro_get( 'accent1' ) );
	$a2 = sanitize_hex_color( cpro_get( 'accent2' ) );
	if ( $a1 && $a2 ) {
		wp_add_inline_style( 'config-pro', ':root{--a1:' . $a1 . ';--a2:' . $a2 . ';}' );
	}
	wp_enqueue_script( 'config-pro', get_template_directory_uri() . '/assets/js/main.js', array(), CPRO_VER, true );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
} );

/* ---------- Helpers ---------- */
function cpro_tg() {
	return ltrim( trim( (string) cpro_get( 'telegram' ) ), '@' );
}

function cpro_tg_url( $text = '' ) {
	$id = cpro_tg();
	if ( '' === $id ) {
		return '';
	}
	$url = 'https://t.me/' . rawurlencode( $id );
	if ( '' !== $text ) {
		$url .= '?text=' . rawurlencode( $text );
	}
	return $url;
}

/* ---------- WooCommerce layout ---------- */
add_action( 'init', function () {
	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
	remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
} );

add_filter( 'loop_shop_columns', function () {
	return 4;
} );

/* Quick buy via Telegram on single product page */
add_action( 'woocommerce_single_product_summary', function () {
	global $product;
	if ( ! $product || '' === cpro_tg() ) {
		return;
	}
	$msg = 'سلام، می‌خوام این پلن رو بخرم: ' . $product->get_name();
	echo '<a class="btn btn-ghost tg-buy" href="' . esc_url( cpro_tg_url( $msg ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'خرید سریع از تلگرام', 'config-pro' ) . '</a>';
}, 35 );

/* Cart count refresh in header */
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	ob_start();
	cpro_cart_link();
	$fragments['a.cart-link'] = ob_get_clean();
	return $fragments;
} );

function cpro_cart_link() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		echo '<a class="cart-link" href="#"></a>';
		return;
	}
	printf(
		'<a class="cart-link" href="%s">🛒 %s <span>(%s)</span></a>',
		esc_url( wc_get_cart_url() ),
		esc_html__( 'سبد خرید', 'config-pro' ),
		esc_html( number_format_i18n( WC()->cart->get_cart_contents_count() ) )
	);
}

/* ---------- Menu fallback ---------- */
function cpro_menu_fallback() {
	echo '<ul><li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'خانه', 'config-pro' ) . '</a></li></ul>';
}

/* ---------- Excerpt ---------- */
add_filter( 'excerpt_length', function () {
	return 28;
}, 999 );
add_filter( 'excerpt_more', function () {
	return '…';
} );
