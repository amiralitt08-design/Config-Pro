<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>
<main id="content" class="container">
	<?php
	while ( have_posts() ) :
		the_post();
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'prose' ); ?>>
			<header class="page-head">
				<h1><?php the_title(); ?></h1>
				<div class="meta"><?php echo esc_html( get_the_date() ); ?> · <?php the_category( '، ' ); ?></div>
			</header>
			<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'large' ); ?>
			<?php endif; ?>
			<?php the_content(); ?>
			<?php wp_link_pages(); ?>
			<?php the_tags( '<p class="meta">', '، ', '</p>' ); ?>
		</article>
		<?php
		the_post_navigation();
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
	endwhile;
	?>
</main>
<?php
get_footer();
