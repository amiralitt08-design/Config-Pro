<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'پرش به محتوا', 'config-pro' ); ?></a>
<header class="site-header">
	<div class="container hd">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<?php
			if ( has_custom_logo() ) {
				the_custom_logo();
			} else {
				echo esc_html( get_bloginfo( 'name' ) );
			}
			?>
		</a>
		<button class="menu-toggle" aria-expanded="false" aria-controls="primary-nav"><?php esc_html_e( 'منو', 'config-pro' ); ?></button>
		<nav class="nav" id="primary-nav" aria-label="<?php esc_attr_e( 'منوی اصلی', 'config-pro' ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'fallback_cb'    => 'cpro_menu_fallback',
				'depth'          => 1,
			) );
			?>
		</nav>
		<div class="hd-actions">
			<?php if ( function_exists( 'WC' ) ) : ?>
				<?php cpro_cart_link(); ?>
			<?php endif; ?>
			<?php if ( '' !== cpro_tg() ) : ?>
				<a class="btn" href="<?php echo esc_url( cpro_tg_url() ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'تلگرام', 'config-pro' ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</header>
