<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<footer class="site-footer">
	<div class="container">
		<div class="ft">
			<div>
				<h4><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h4>
				<p><?php echo esc_html( cpro_get( 'footer_text' ) ); ?></p>
			</div>
			<div>
				<h4><?php esc_html_e( 'لینک‌ها', 'config-pro' ); ?></h4>
				<?php
				wp_nav_menu( array(
					'theme_location' => 'footer',
					'container'      => false,
					'fallback_cb'    => false,
					'depth'          => 1,
				) );
				?>
			</div>
			<div>
				<h4><?php esc_html_e( 'ارتباط با ما', 'config-pro' ); ?></h4>
				<?php if ( '' !== cpro_tg() ) : ?>
					<p><a href="<?php echo esc_url( cpro_tg_url() ); ?>" target="_blank" rel="noopener">@<?php echo esc_html( cpro_tg() ); ?></a></p>
				<?php endif; ?>
			</div>
		</div>
		<div class="copy">© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?></div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
