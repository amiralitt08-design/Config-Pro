<?php
/**
 * Blog index, archives and search results.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>
<main id="content" class="container">
	<header class="page-head">
		<h1>
			<?php
			if ( is_search() ) {
				/* translators: %s: search query */
				printf( esc_html__( 'نتایج جستجو برای: %s', 'config-pro' ), esc_html( get_search_query() ) );
			} elseif ( is_archive() ) {
				the_archive_title();
			} else {
				esc_html_e( 'وبلاگ', 'config-pro' );
			}
			?>
		</h1>
	</header>
	<?php if ( have_posts() ) : ?>
		<div class="posts">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
					<?php if ( has_post_thumbnail() ) : ?>
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'medium_large' ); ?></a>
					<?php endif; ?>
					<div class="in">
						<h2><a href="<?php the_permalink(); ?>" style="color:inherit"><?php the_title(); ?></a></h2>
						<div class="meta"><?php echo esc_html( get_the_date() ); ?></div>
						<p><?php echo esc_html( get_the_excerpt() ); ?></p>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
		<?php the_posts_pagination( array( 'mid_size' => 1 ) ); ?>
	<?php else : ?>
		<div class="prose"><p><?php esc_html_e( 'مطلبی پیدا نشد.', 'config-pro' ); ?></p><?php get_search_form(); ?></div>
	<?php endif; ?>
</main>
<?php
get_footer();
