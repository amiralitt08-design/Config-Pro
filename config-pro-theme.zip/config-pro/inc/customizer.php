<?php
/**
 * Customizer: every front page section is editable from Appearance > Customize.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function cpro_defaults() {
	return array(
		'telegram'     => 'Alirezat0p',
		'accent1'      => '#a855f7',
		'accent2'      => '#22d3ee',
		'hero_badge'   => 'سرعت بالا • پشتیبانی سریع',
		'hero_title'   => 'کانفیگ پرسرعت برای اندروید و iOS',
		'hero_text'    => 'پک اقتصادی، پک ویژه و پک نامحدود با قیمت مناسب و تحویل سریع.',
		'hero_btn'     => 'مشاهده پلن‌ها',
		'hero_btn_url' => '#plans',
		'hero_btn2'    => 'خرید از تلگرام',
		'show_features' => '1',
		'f1_t' => 'سرعت بالا',   'f1_d' => 'اتصال پایدار و سریع برای کار و سرگرمی.',
		'f2_t' => 'اندروید و iOS', 'f2_d' => 'روی همه‌ی گوشی‌ها و کامپیوتر کار می‌کند.',
		'f3_t' => 'تحویل سریع',   'f3_d' => 'بعد از پرداخت، کانفیگ سریع برایتان ارسال می‌شود.',
		'f4_t' => 'پشتیبانی',     'f4_d' => 'هر سؤالی داشتید در تلگرام پیام بدهید.',
		'show_plans'   => '1',
		'plans_title'  => 'پلن‌ها و قیمت‌ها',
		'plans_text'   => 'پلن مورد نظرت را انتخاب کن.',
		'show_steps'   => '1',
		's1_t' => 'پلن را انتخاب کنید', 's1_d' => 'حجم یا مدت دلخواه را از لیست انتخاب کنید.',
		's2_t' => 'پرداخت',            's2_d' => 'سفارش را ثبت و پرداخت را انجام دهید.',
		's3_t' => 'دریافت کانفیگ',      's3_d' => 'کانفیگ را دریافت و در برنامه وارد کنید.',
		'show_faq'     => '1',
		'faq_title'    => 'سوالات متداول',
		'q1' => 'کانفیگ روی چه دستگاه‌هایی کار می‌کند؟', 'a1' => 'روی اندروید، iOS، ویندوز و مک.',
		'q2' => 'بعد از خرید چطور کانفیگ را می‌گیرم؟',   'a2' => 'بعد از ثبت سفارش، کانفیگ در تلگرام یا ایمیل برایتان ارسال می‌شود.',
		'q3' => 'برای حجم بیشتر چه کار کنم؟',            'a3' => 'برای حجم‌های بالاتر از ۲۰۰ گیگ در تلگرام پیام بدهید.',
		'q4' => 'پشتیبانی چطور است؟',                    'a4' => 'از طریق تلگرام پاسخگو هستیم.',
		'show_cta'     => '1',
		'cta_title'    => 'آماده‌ای شروع کنی؟',
		'cta_text'     => 'همین الان پلن خودت را انتخاب کن یا در تلگرام پیام بده.',
		'cta_btn'      => 'پیام در تلگرام',
		'footer_text'  => 'فروش کانفیگ پرسرعت برای اندروید و iOS.',
	);
}

function cpro_get( $key ) {
	$d = cpro_defaults();
	return get_theme_mod( 'cpro_' . $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
}

function cpro_sanitize_check( $v ) {
	return ( isset( $v ) && true == $v ) ? '1' : '0';
}

add_action( 'customize_register', function ( $wp_customize ) {
	$d = cpro_defaults();

	$add = function ( $section, $key, $label, $type = 'text' ) use ( $wp_customize, $d ) {
		if ( 'color' === $type ) {
			$wp_customize->add_setting( 'cpro_' . $key, array(
				'default'           => $d[ $key ],
				'sanitize_callback' => 'sanitize_hex_color',
			) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cpro_' . $key, array( 'label' => $label, 'section' => $section ) ) );
			return;
		}
		$san = 'sanitize_text_field';
		if ( 'textarea' === $type ) {
			$san = 'sanitize_textarea_field';
		} elseif ( 'url' === $type ) {
			$san = 'esc_url_raw';
		} elseif ( 'checkbox' === $type ) {
			$san = 'cpro_sanitize_check';
		}
		$wp_customize->add_setting( 'cpro_' . $key, array(
			'default'           => isset( $d[ $key ] ) ? $d[ $key ] : '',
			'sanitize_callback' => $san,
		) );
		$wp_customize->add_control( 'cpro_' . $key, array( 'label' => $label, 'section' => $section, 'type' => $type ) );
	};

	$wp_customize->add_panel( 'cpro_panel', array( 'title' => 'تنظیمات Config Pro', 'priority' => 30 ) );

	$wp_customize->add_section( 'cpro_general', array( 'title' => 'عمومی', 'panel' => 'cpro_panel' ) );
	$add( 'cpro_general', 'telegram', 'آیدی تلگرام (بدون @)' );
	$add( 'cpro_general', 'accent1', 'رنگ اصلی', 'color' );
	$add( 'cpro_general', 'accent2', 'رنگ دوم', 'color' );
	$add( 'cpro_general', 'footer_text', 'متن فوتر', 'textarea' );

	$wp_customize->add_section( 'cpro_hero', array( 'title' => 'بخش اصلی (Hero)', 'panel' => 'cpro_panel' ) );
	$add( 'cpro_hero', 'hero_badge', 'نشان بالای عنوان' );
	$add( 'cpro_hero', 'hero_title', 'عنوان' );
	$add( 'cpro_hero', 'hero_text', 'توضیح', 'textarea' );
	$add( 'cpro_hero', 'hero_btn', 'متن دکمه‌ی اول' );
	$add( 'cpro_hero', 'hero_btn_url', 'لینک دکمه‌ی اول' );
	$add( 'cpro_hero', 'hero_btn2', 'متن دکمه‌ی تلگرام' );

	$wp_customize->add_section( 'cpro_features', array( 'title' => 'ویژگی‌ها', 'panel' => 'cpro_panel' ) );
	$add( 'cpro_features', 'show_features', 'نمایش این بخش', 'checkbox' );
	for ( $i = 1; $i <= 4; $i++ ) {
		$add( 'cpro_features', "f{$i}_t", "ویژگی {$i}: عنوان" );
		$add( 'cpro_features', "f{$i}_d", "ویژگی {$i}: توضیح", 'textarea' );
	}

	$wp_customize->add_section( 'cpro_plans', array( 'title' => 'پلن‌ها (محصولات)', 'panel' => 'cpro_panel' ) );
	$add( 'cpro_plans', 'show_plans', 'نمایش این بخش', 'checkbox' );
	$add( 'cpro_plans', 'plans_title', 'عنوان' );
	$add( 'cpro_plans', 'plans_text', 'توضیح' );

	$wp_customize->add_section( 'cpro_steps', array( 'title' => 'مراحل خرید', 'panel' => 'cpro_panel' ) );
	$add( 'cpro_steps', 'show_steps', 'نمایش این بخش', 'checkbox' );
	for ( $i = 1; $i <= 3; $i++ ) {
		$add( 'cpro_steps', "s{$i}_t", "مرحله {$i}: عنوان" );
		$add( 'cpro_steps', "s{$i}_d", "مرحله {$i}: توضیح", 'textarea' );
	}

	$wp_customize->add_section( 'cpro_faq', array( 'title' => 'سوالات متداول', 'panel' => 'cpro_panel' ) );
	$add( 'cpro_faq', 'show_faq', 'نمایش این بخش', 'checkbox' );
	$add( 'cpro_faq', 'faq_title', 'عنوان' );
	for ( $i = 1; $i <= 4; $i++ ) {
		$add( 'cpro_faq', "q{$i}", "سؤال {$i}" );
		$add( 'cpro_faq', "a{$i}", "پاسخ {$i}", 'textarea' );
	}

	$wp_customize->add_section( 'cpro_cta', array( 'title' => 'دعوت به اقدام', 'panel' => 'cpro_panel' ) );
	$add( 'cpro_cta', 'show_cta', 'نمایش این بخش', 'checkbox' );
	$add( 'cpro_cta', 'cta_title', 'عنوان' );
	$add( 'cpro_cta', 'cta_text', 'توضیح', 'textarea' );
	$add( 'cpro_cta', 'cta_btn', 'متن دکمه' );
} );
