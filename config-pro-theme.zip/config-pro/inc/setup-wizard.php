<?php
/**
 * One-click setup: pages, menus, sample products, basic settings.
 * Runs only after an administrator ticks the confirmation box and submits the form.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	add_theme_page( 'ابزار راه‌اندازی', 'ابزار راه‌اندازی', 'manage_options', 'cpro-setup', 'cpro_setup_page' );
} );

add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) || get_option( 'cpro_setup_done' ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( $screen && 'appearance_page_cpro-setup' === $screen->id ) {
		return;
	}
	printf(
		'<div class="notice notice-info"><p>قالب Config Pro فعال شد. برای ساخت خودکار صفحات، منو و محصولات نمونه <a href="%s"><strong>ابزار راه‌اندازی</strong></a> را اجرا کنید.</p></div>',
		esc_url( admin_url( 'themes.php?page=cpro-setup' ) )
	);
} );

function cpro_sample_data() {
	return array(
		'economy'   => array( 'پک معمولی اقتصادی اندروید', array(
			array( 'E10', '10 گیگ', 80000 ), array( 'E20', '20 گیگ', 160000 ), array( 'E30', '30 گیگ', 180000 ),
			array( 'E40', '40 گیگ', 210000 ), array( 'E50', '50 گیگ', 300000 ), array( 'E100', '100 گیگ', 400000 ),
			array( 'E150', '150 گیگ', 700000 ), array( 'E200', '200 گیگ', 1000000 ),
		) ),
		'special'   => array( 'پک ویژه با سرعت ویژه (اندروید و iOS)', array(
			array( 'V10', '10 گیگ', 140000 ), array( 'V20', '20 گیگ', 220000 ), array( 'V30', '30 گیگ', 360000 ),
			array( 'V50', '50 گیگ', 440000 ), array( 'V100', '100 گیگ', 850000 ), array( 'V200', '200 گیگ', 2000000 ),
		) ),
		'unlimited' => array( 'پک نامحدود پرو مکس (اندروید و iOS)', array(
			array( 'U1', 'نامحدود 1 ماهه', 400000 ), array( 'U2', 'نامحدود 2 ماهه', 600000 ),
			array( 'U3', 'نامحدود 3 ماهه', 800000 ), array( 'U4', 'نامحدود 4 ماهه', 1000000 ),
		) ),
	);
}

function cpro_setup_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$done = isset( $_GET['cpro_done'] ); // phpcs:ignore WordPress.Security.NonceVerification
	?>
	<div class="wrap">
		<h1>ابزار راه‌اندازی Config Pro</h1>
		<?php if ( $done ) : ?>
			<div class="notice notice-success"><p>راه‌اندازی انجام شد. حالا می‌توانید از «نمایش ← سفارشی‌سازی ← تنظیمات Config Pro» متن‌ها را عوض کنید.</p></div>
			<?php
			$msg = get_transient( 'cpro_setup_msg' );
			if ( $msg ) {
				echo '<div class="notice notice-warning"><p>' . esc_html( $msg ) . '</p></div>';
				delete_transient( 'cpro_setup_msg' );
			}
			?>
		<?php endif; ?>
		<p>با یک کلیک این کارها انجام می‌شود (چیزی که از قبل وجود دارد دوباره ساخته نمی‌شود):</p>
		<ul style="list-style:disc;padding-inline-start:20px">
			<li>ساخت صفحات: خانه، وبلاگ، درباره ما، تماس با ما، قوانین، سوالات متداول، راهنمای اتصال</li>
			<li>تنظیم صفحه‌ی خانه به‌عنوان صفحه‌ی اصلی سایت و صفحه‌ی وبلاگ برای نوشته‌ها</li>
			<li>ساخت منوی اصلی و منوی فوتر و اتصال آن‌ها به قالب</li>
			<li>ساخت دسته‌بندی‌ها و محصولات نمونه (ووکامرس) با قیمت‌های لیست شما</li>
			<li>تنظیم واحد پول ووکامرس روی تومان (اگر نسخه‌ی ووکامرس پشتیبانی کند)، منطقه‌ی زمانی تهران و پیوند یکتای «نام نوشته»</li>
		</ul>
		<?php if ( ! class_exists( 'WooCommerce' ) ) : ?>
			<div class="notice notice-warning inline"><p>ووکامرس نصب یا فعال نیست. اول افزونه‌ی ووکامرس را نصب و فعال کنید؛ در غیر این صورت بخش محصولات ساخته نمی‌شود.</p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="cpro_run_setup">
			<?php wp_nonce_field( 'cpro_run_setup', 'cpro_nonce' ); ?>
			<p><label><input type="checkbox" name="cpro_confirm" value="1" required> تأیید می‌کنم که این تغییرات روی سایت اعمال شود.</label></p>
			<p><button type="submit" class="button button-primary button-hero">راه‌اندازی با یک کلیک</button></p>
		</form>
	</div>
	<?php
}

add_action( 'admin_post_cpro_run_setup', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'اجازه‌ی دسترسی ندارید.', 403 );
	}
	check_admin_referer( 'cpro_run_setup', 'cpro_nonce' );
	if ( empty( $_POST['cpro_confirm'] ) ) {
		wp_safe_redirect( admin_url( 'themes.php?page=cpro-setup' ) );
		exit;
	}

	$notes = array();

	/* 1) pages */
	$p = array();
	$p['home']    = cpro_make_page( 'خانه', 'home', '' );
	$p['blog']    = cpro_make_page( 'وبلاگ', 'blog', '' );
	$p['about']   = cpro_make_page( 'درباره ما', 'about', '<p>ما ارائه‌دهنده‌ی کانفیگ پرسرعت برای اندروید و iOS هستیم. این متن را از بخش صفحات ویرایش کنید.</p>' );
	$p['contact'] = cpro_make_page( 'تماس با ما', 'contact', '<p>برای خرید و پشتیبانی در تلگرام پیام بدهید: <a href="' . esc_url( cpro_tg_url() ) . '">@' . esc_html( cpro_tg() ) . '</a></p>' );
	$p['rules']   = cpro_make_page( 'قوانین', 'rules', '<p>قوانین و شرایط استفاده از خدمات را اینجا بنویسید.</p>' );
	$p['faq']     = cpro_make_page( 'سوالات متداول', 'faq', '<p>سوالات پرتکرار مشتریان را اینجا بنویسید.</p>' );
	$p['guide']   = cpro_make_page( 'راهنمای اتصال', 'guide', '<ol><li>برنامه‌ی مناسب گوشی خود را نصب کنید.</li><li>لینک اشتراک یا کانفیگ را کپی کنید.</li><li>در برنامه گزینه‌ی افزودن را بزنید و کانفیگ را وارد کنید.</li></ol>' );

	/* 2) reading settings */
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $p['home'] );
	update_option( 'page_for_posts', $p['blog'] );

	/* 3) menus */
	$locations = get_theme_mod( 'nav_menu_locations', array() );
	$main      = cpro_make_menu( 'منوی اصلی' );
	if ( $main ) {
		cpro_menu_add_page( $main, $p['home'], 'خانه' );
		if ( function_exists( 'wc_get_page_id' ) && wc_get_page_id( 'shop' ) > 0 ) {
			cpro_menu_add_page( $main, wc_get_page_id( 'shop' ), 'فروشگاه' );
		}
		cpro_menu_add_page( $main, $p['guide'], 'راهنمای اتصال' );
		cpro_menu_add_page( $main, $p['blog'], 'وبلاگ' );
		cpro_menu_add_page( $main, $p['faq'], 'سوالات متداول' );
		cpro_menu_add_page( $main, $p['contact'], 'تماس با ما' );
		$locations['primary'] = $main;
	}
	$foot = cpro_make_menu( 'منوی فوتر' );
	if ( $foot ) {
		cpro_menu_add_page( $foot, $p['about'], 'درباره ما' );
		cpro_menu_add_page( $foot, $p['rules'], 'قوانین' );
		cpro_menu_add_page( $foot, $p['contact'], 'تماس با ما' );
		if ( function_exists( 'wc_get_page_id' ) && wc_get_page_id( 'myaccount' ) > 0 ) {
			cpro_menu_add_page( $foot, wc_get_page_id( 'myaccount' ), 'حساب کاربری' );
		}
		$locations['footer'] = $foot;
	}
	set_theme_mod( 'nav_menu_locations', $locations );

	/* 4) WooCommerce products */
	if ( class_exists( 'WooCommerce' ) && class_exists( 'WC_Product_Simple' ) ) {
		if ( function_exists( 'get_woocommerce_currencies' ) && array_key_exists( 'IRT', get_woocommerce_currencies() ) ) {
			update_option( 'woocommerce_currency', 'IRT' );
			update_option( 'woocommerce_price_num_decimals', 0 );
			update_option( 'woocommerce_price_thousand_sep', ',' );
		} else {
			$notes[] = 'نسخه‌ی ووکامرس شما واحد «تومان» را ندارد؛ واحد پول را دستی از تنظیمات ووکامرس انتخاب کنید.';
		}
		$order = 0;
		foreach ( cpro_sample_data() as $slug => $pack ) {
			$term = term_exists( $slug, 'product_cat' );
			if ( ! $term ) {
				$term = wp_insert_term( $pack[0], 'product_cat', array( 'slug' => $slug ) );
			}
			if ( is_wp_error( $term ) ) {
				continue;
			}
			$term_id = (int) ( is_array( $term ) ? $term['term_id'] : $term );
			foreach ( $pack[1] as $row ) {
				if ( wc_get_product_id_by_sku( $row[0] ) ) {
					continue;
				}
				$prod = new WC_Product_Simple();
				$prod->set_name( $row[1] . ' - ' . $pack[0] );
				$prod->set_sku( $row[0] );
				$prod->set_regular_price( (string) $row[2] );
				$prod->set_virtual( true );
				$prod->set_status( 'publish' );
				$prod->set_catalog_visibility( 'visible' );
				$prod->set_category_ids( array( $term_id ) );
				$prod->set_menu_order( $order++ );
				$prod->set_short_description( $pack[0] . ' - ' . $row[1] );
				$prod->save();
			}
		}
	} else {
		$notes[] = 'ووکامرس فعال نبود، بنابراین محصولات نمونه ساخته نشد. بعد از فعال‌سازی ووکامرس، ابزار را دوباره اجرا کنید.';
	}

	/* 5) basic settings */
	if ( '' === get_option( 'timezone_string' ) ) {
		update_option( 'timezone_string', 'Asia/Tehran' );
	}
	if ( '' === get_option( 'permalink_structure' ) ) {
		update_option( 'permalink_structure', '/%postname%/' );
	}
	if ( '' === trim( (string) get_option( 'blogdescription' ) ) || 'Just another WordPress site' === get_option( 'blogdescription' ) ) {
		update_option( 'blogdescription', 'فروش کانفیگ پرسرعت اندروید و iOS' );
	}
	flush_rewrite_rules();

	update_option( 'cpro_setup_done', 1 );
	if ( $notes ) {
		set_transient( 'cpro_setup_msg', implode( ' ', $notes ), 120 );
	}
	wp_safe_redirect( admin_url( 'themes.php?page=cpro-setup&cpro_done=1' ) );
	exit;
} );

function cpro_make_page( $title, $slug, $content ) {
	$existing = get_page_by_path( $slug );
	if ( $existing ) {
		return (int) $existing->ID;
	}
	$id = wp_insert_post( array(
		'post_title'   => $title,
		'post_name'    => $slug,
		'post_content' => $content,
		'post_status'  => 'publish',
		'post_type'    => 'page',
	) );
	return is_wp_error( $id ) ? 0 : (int) $id;
}

function cpro_make_menu( $name ) {
	$menu = wp_get_nav_menu_object( $name );
	if ( $menu ) {
		return (int) $menu->term_id;
	}
	$id = wp_create_nav_menu( $name );
	return is_wp_error( $id ) ? 0 : (int) $id;
}

function cpro_menu_add_page( $menu_id, $page_id, $title ) {
	if ( ! $page_id ) {
		return;
	}
	foreach ( (array) wp_get_nav_menu_items( $menu_id ) as $item ) {
		if ( (int) $item->object_id === (int) $page_id ) {
			return;
		}
	}
	wp_update_nav_menu_item( $menu_id, 0, array(
		'menu-item-title'     => $title,
		'menu-item-object'    => 'page',
		'menu-item-object-id' => $page_id,
		'menu-item-type'      => 'post_type',
		'menu-item-status'    => 'publish',
	) );
}
