<?php
/**
 * Front page: all sections are managed from Customizer.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();

$on = function ( $k ) {
	return '1' === (string) cpro_get( $k );
};
?>
<main id="content">

	<section class="hero">
		<div class="container">
			<?php if ( cpro_get( 'hero_badge' ) ) : ?><span class="badge"><?php echo esc_html( cpro_get( 'hero_badge' ) ); ?></span><?php endif; ?>
			<h1 class="grad"><?php echo esc_html( cpro_get( 'hero_title' ) ); ?></h1>
			<p><?php echo esc_html( cpro_get( 'hero_text' ) ); ?></p>
			<div class="row">
				<?php if ( cpro_get( 'hero_btn' ) ) : ?>
					<a class="btn" href="<?php echo esc_url( cpro_get( 'hero_btn_url' ) ); ?>"><?php echo esc_html( cpro_get( 'hero_btn' ) ); ?></a>
				<?php endif; ?>
				<?php if ( '' !== cpro_tg() && cpro_get( 'hero_btn2' ) ) : ?>
					<a class="btn btn-ghost" href="<?php echo esc_url( cpro_tg_url() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( cpro_get( 'hero_btn2' ) ); ?></a>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<?php if ( $on( 'show_features' ) ) : ?>
	<section class="sec">
		<div class="container cards">
			<?php
			$icons = array( '⚡', '📱', '🚀', '💬' );
			for ( $i = 1; $i <= 4; $i++ ) :
				if ( '' === cpro_get( "f{$i}_t" ) ) {
					continue;
				}
				?>
				<div class="card">
					<div class="ico"><?php echo esc_html( $icons[ $i - 1 ] ); ?></div>
					<h3><?php echo esc_html( cpro_get( "f{$i}_t" ) ); ?></h3>
					<p><?php echo esc_html( cpro_get( "f{$i}_d" ) ); ?></p>
				</div>
			<?php endfor; ?>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( $on( 'show_plans' ) ) : ?>
	<section class="sec" id="plans">
		<div class="container">
			<h2 class="sec-title"><?php echo esc_html( cpro_get( 'plans_title' ) ); ?></h2>
			<p class="sec-sub"><?php echo esc_html( cpro_get( 'plans_text' ) ); ?></p>
			<?php
			if ( ! function_exists( 'wc_get_products' ) ) {
				if ( current_user_can( 'manage_options' ) ) {
					echo '<div class="card">برای نمایش پلن‌ها افزونه‌ی ووکامرس را نصب و فعال کنید.</div>';
				}
			} else {
				$cats = get_terms( array(
					'taxonomy'   => 'product_cat',
					'hide_empty' => true,
					'exclude'    => array( (int) get_option( 'default_product_cat' ) ),
					'orderby'    => 'term_id',
				) );
				if ( is_wp_error( $cats ) || empty( $cats ) ) {
					if ( current_user_can( 'manage_options' ) ) {
						echo '<div class="card">هنوز محصولی ثبت نشده. از «نمایش ← ابزار راه‌اندازی» محصولات نمونه را بسازید یا محصول اضافه کنید.</div>';
					}
				} else {
					foreach ( $cats as $cat ) {
						$products = wc_get_products( array(
							'status'   => 'publish',
							'limit'    => 40,
							'category' => array( $cat->slug ),
							'orderby'  => 'menu_order',
							'order'    => 'ASC',
						) );
						if ( ! $products ) {
							continue;
						}
						echo '<h3 class="pack-title">' . esc_html( $cat->name ) . '</h3><div class="plans">';
						foreach ( $products as $prod ) {
							?>
							<div class="plan">
								<h4><a href="<?php echo esc_url( $prod->get_permalink() ); ?>" style="color:inherit"><?php echo esc_html( preg_replace( '/\s+-\s+.*$/u', '', $prod->get_name() ) ); ?></a></h4>
								<div class="price"><?php echo wp_kses_post( $prod->get_price_html() ); ?></div>
								<a class="btn add_to_cart_button" href="<?php echo esc_url( $prod->add_to_cart_url() ); ?>" data-product_id="<?php echo esc_attr( $prod->get_id() ); ?>" data-quantity="1" rel="nofollow"><?php esc_html_e( 'خرید', 'config-pro' ); ?></a>
							</div>
							<?php
						}
						echo '</div>';
					}
				}
			}
			?>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( $on( 'show_steps' ) ) : ?>
	<section class="sec">
		<div class="container cards steps">
			<?php
			for ( $i = 1; $i <= 3; $i++ ) :
				if ( '' === cpro_get( "s{$i}_t" ) ) {
					continue;
				}
				?>
				<div class="card">
					<div class="num"><?php echo esc_html( number_format_i18n( $i ) ); ?></div>
					<h3><?php echo esc_html( cpro_get( "s{$i}_t" ) ); ?></h3>
					<p><?php echo esc_html( cpro_get( "s{$i}_d" ) ); ?></p>
				</div>
			<?php endfor; ?>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( $on( 'show_faq' ) ) : ?>
	<section class="sec">
		<div class="container faq" style="max-width:820px">
			<h2 class="sec-title"><?php echo esc_html( cpro_get( 'faq_title' ) ); ?></h2>
			<?php
			for ( $i = 1; $i <= 4; $i++ ) :
				if ( '' === cpro_get( "q{$i}" ) ) {
					continue;
				}
				?>
				<details>
					<summary><?php echo esc_html( cpro_get( "q{$i}" ) ); ?></summary>
					<p><?php echo esc_html( cpro_get( "a{$i}" ) ); ?></p>
				</details>
			<?php endfor; ?>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( $on( 'show_cta' ) ) : ?>
	<section class="sec">
		<div class="container">
			<div class="cta">
				<h2><?php echo esc_html( cpro_get( 'cta_title' ) ); ?></h2>
				<p><?php echo esc_html( cpro_get( 'cta_text' ) ); ?></p>
				<?php if ( '' !== cpro_tg() ) : ?>
					<a class="btn" href="<?php echo esc_url( cpro_tg_url() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( cpro_get( 'cta_btn' ) ); ?></a>
				<?php endif; ?>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<?php
	// Extra content written in the Gutenberg editor on the front page itself.
	while ( have_posts() ) {
		the_post();
		if ( '' !== trim( get_the_content() ) ) {
			echo '<section class="container prose">';
			the_content();
			echo '</section>';
		}
	}
	?>
</main>
<?php
get_footer();
